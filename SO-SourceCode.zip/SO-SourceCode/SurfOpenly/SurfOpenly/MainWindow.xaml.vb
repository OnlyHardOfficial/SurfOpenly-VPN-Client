﻿'SurfOpenly is an open source project licensed under GPL (General Public License or GNU)
'Source code is written by Zubair Khalid (An indie software developer)
'For quieres, email at zubarkhald130@gmail.com or visit www.facebook.com/m.zubair.30

Imports System
Imports System.Windows
Imports System.Windows.Threading

Imports DotRas 'DotRas is an API provides remote access service (RAS) components for .NET languages like C#, VB.NET, and C++ CLR projects 
Class MainWindow

    Dim candrag As Boolean = True 'Used in dragging the borderless form, True mean we can drag the form anywhere
    Dim phonebook As RasPhoneBook = New RasPhoneBook 'This phonebook holds the entires to connect. From details host/server, username, password, pre-shared key a phonebook entry is formed which is dialed for connection.
    Dim rasdialer As RasDialer = New RasDialer 'This dialer dials the entries of phonebook
    Dim rashandler As RasHandle 'This controls the behaviour of dialer, like dial completed events or events while connection is being established.
    Dim rasConWatcher As RasConnectionWatcher = New RasConnectionWatcher 'This monitors the established connection
    Dim conup As Boolean = False 'If True then it indcates that a connection is established, used at closing of application to check whether a connection is alive or not, if an alive connection is found then it is first diconnected.
    Dim tempProtocolName As String 'It holds the name of protocol selected for connection, used to write log file.
    Dim tempPSKEY As String 'It holds the pre-shared key, used to write log file.
    Dim intDisconnected As Boolean = False 'If false then indicates that connection is disconnected by exteral factors like internet connection lost.
    Private Sub MainWindow_Initialized(sender As Object, e As EventArgs) Handles Me.Initialized
        'Last time saved values of connection, with which a successful connection was established, are resotred back to fields,
        tb_server.Text = My.Settings.serveradd
        tb_username.Text = My.Settings.serveruser
        tb_psdd.Text = My.Settings.serverpass
        tb_pskey.Text = My.Settings.serverpskey
        com_protocols.SelectedIndex = My.Settings.index
        rasConWatcher.EnableRaisingEvents = True



        'Generates a log file if not present
        If (Not IO.File.Exists(My.Application.Info.DirectoryPath + "\logs.txt")) Then
            IO.File.WriteAllText(My.Application.Info.DirectoryPath + "\logs.txt", "<----- SurfOpenly Logging ---->" + vbNewLine + "< To Clear log file, delete all text below this line. >")
        End If
        IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  SurfOpenly Application Initialized")



    End Sub



    Private Sub MainWindow_MouseDown(sender As Object, e As MouseButtonEventArgs) Handles Me.MouseDown
        candrag = True
    End Sub



    Private Sub MainWindow_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        'If user holds mouse on form and move mouse then allow user to drag it.
        If e.LeftButton = MouseButtonState.Pressed = True Then
            If candrag = True Then
                Me.DragMove()
            End If

        End If
    End Sub

    Private Sub com_protocols_MouseEnter(sender As Object, e As MouseEventArgs) Handles com_protocols.MouseEnter
        candrag = False
    End Sub


    Private Sub com_protocols_SelectionChanged(sender As Object, e As SelectionChangedEventArgs) Handles com_protocols.SelectionChanged

        'If the user selects L2TP protocol then a text field becomes visible where user can write pre-shared key.
        If com_protocols.SelectedIndex = 2 Then
            lb6.Visibility = Windows.Visibility.Visible
            tb_pskey.Visibility = Windows.Visibility.Visible
        Else
            lb6.Visibility = Windows.Visibility.Hidden
            tb_pskey.Visibility = Windows.Visibility.Hidden
        End If
    End Sub

    Private Sub com_servers_MouseEnter(sender As Object, e As MouseEventArgs) Handles com_servers.MouseEnter
        candrag = False 'Disallow dragging of form if object on which mouse is down is not form object.
    End Sub
    Private Sub tb_psdd_MouseEnter(sender As Object, e As MouseEventArgs) Handles tb_psdd.MouseEnter
        candrag = False 'Disallow dragging of form if object on which mouse is down is not form object.
    End Sub
    Private Sub tb_pskey_MouseEnter(sender As Object, e As MouseEventArgs) Handles tb_pskey.MouseEnter
        candrag = False 'Disallow dragging of form if object on which mouse is down is not form object.
    End Sub
    Private Sub tb_server_MouseEnter(sender As Object, e As MouseEventArgs) Handles tb_server.MouseEnter
        candrag = False 'Disallow dragging of form if object on which mouse is down is not form object.
    End Sub
    Private Sub tb_username_MouseEnter(sender As Object, e As MouseEventArgs) Handles tb_username.MouseEnter
        candrag = False 'Disallow dragging of form if object on which mouse is down is not form object.
    End Sub


    Private Sub connection()
        'User must fill the empty fields.
        If tb_server.Text = String.Empty Or tb_username.Text = String.Empty Or tb_psdd.Text = String.Empty Then
            MsgBox("All fields are required", MsgBoxStyle.Exclamation, "Empty Fields")
            Exit Sub
        End If
        intDisconnected = False
        'Single button is used to connect/disconnect. If label of button is Connect, it means no connection is alive therefore make a new connection. 
        If lb_con.Content = "Connect" Then

            IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  Trying to establish a connection")

            'Check if computer is connected to internet and have internet access.
            If (CheckInternetConnection() = True) Then
                Try
                    AddHandler rasdialer.DialCompleted, AddressOf dialcomplete 'Attach a sub to handler to control dialer complete events.
                    AddHandler rasdialer.StateChanged, AddressOf dialstatechanged 'Attach a sub to handler to control dialer state change events.
                    AddHandler rasConWatcher.Disconnected, AddressOf connectionInterrupted 'Attach a sub to handler to control connection watcher disconnected event.

                    phonebook.Open() 'Phonebook must be opened before making connections.

                    Dim rasstrategy As RasVpnStrategy 'The Strategy defines the protocol being used for making connections. i.e. PPTP, SSTP, L2TP
                    If com_protocols.SelectedIndex = 0 Then
                        tempProtocolName = "PPTP"
                        rasstrategy = RasVpnStrategy.PptpOnly
                    ElseIf com_protocols.SelectedIndex = 1 Then
                        tempProtocolName = "SSTP"
                        rasstrategy = RasVpnStrategy.SstpOnly
                    ElseIf com_protocols.SelectedIndex = 2 Then
                        tempProtocolName = "LT2P"
                        rasstrategy = RasVpnStrategy.L2tpOnly
                    End If

                    'Create a phonebook entry.
                    Dim vpn As RasEntry = RasEntry.CreateVpnEntry("SurfOpenly (" + tb_server.Text + ")", tb_server.Text, rasstrategy, RasDevice.Create("SurfOpenly", RasDeviceType.Vpn))

                    'Allow the entry to use credentials like username and password.
                    vpn.Options.UseLogOnCredentials = True

                    'If the user selected L2TP protocol then we must allow and proivde pre-shared key for this entry.
                    If rasstrategy = RasVpnStrategy.L2tpOnly Then
                        vpn.Options.UsePreSharedKey = True
                        tempPSKEY = tb_pskey.Text
                    Else
                        tempPSKEY = "None"
                    End If
                    phonebook.Entries.Clear() 'Clear phonebook for old entries, if you want to retain old entries then comment or delete this line, but be sure no duplicate entries.
                    phonebook.Entries.Add(vpn)
                    'If the user selected L2TP protocol then we must allow and proivde pre-shared key for this entry.
                    If rasstrategy = RasVpnStrategy.L2tpOnly Then
                        vpn.UpdateCredentials(RasPreSharedKey.Client, tb_pskey.Text)
                    End If
                    rasdialer.EntryName = "SurfOpenly (" + tb_server.Text + ")" 'Defines name of newly created entry.
                    rasdialer.PhoneBookPath = phonebook.Path.ToString 'We must have to provide the path of our phonebook to the dialer.

                    rasdialer.Credentials = New System.Net.NetworkCredential(tb_username.Text, tb_psdd.Text) 'Sets the credentials for current connection.

                    rashandler = rasdialer.DialAsync() 'Dials connection
                    connecting.Visibility = Windows.Visibility.Visible 'Make the logo visible which indicates that a connection is being established
                    lb_con.Content = "Disconnect"
                    lb_con.Margin = New Thickness(364, 192, 0, 0)

                Catch exc As Exception
                    IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  " + exc.Message)

                    MsgBox(exc.Message, MsgBoxStyle.Critical, "Connection Error")

                End Try
            Else
                IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  Either your internet Or server (http: //www.google.com) used to check internet connectivity is down.")

                MsgBox("Either your internet Or server (http: //www.google.com) used to check internet connectivity is down.", MsgBoxStyle.Critical, "Connection Error")
            End If

            'Single button is used to connect/disconnect. If label of button is Disconnect, it means a connection is alive therefore disconnect it. 
        ElseIf lb_con.Content = "Disconnect" Then
            intDisconnected = True
            IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  Trying to disconnect a connection")

            If (rasdialer.IsBusy) Then
                rasdialer.DialAsyncCancel() 'Disconnect connection if it is being established
            Else
                Dim con As RasConnection = RasConnection.GetActiveConnectionByHandle(rashandler) 'First get whether an alive connection is in use or not.

                If (con IsNot Nothing) Then
                    con.HangUp() 'Disconnects a live connection
                End If

            End If
            conup = False
            lb_con.Content = "Connect"
            lb_con.Margin = New Thickness(374, 192, 0, 0)
            lb1.Content = "Let's Connect"
            lb1.Margin = New Thickness(183, 68, 146, 0)
            connecting.Visibility = Windows.Visibility.Hidden 'Make the logo hidden which indicates that a connection is being established

            IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  Successfully diconnected live connection")

        End If


    End Sub

    Public Function CheckInternetConnection() As Boolean
        'Sub to test internet connection
        Try
            Return My.Computer.Network.Ping("www.google.com")
        Catch
            Return False
        End Try

    End Function

    Private Sub connectionInterrupted(sender As System.Object, e As RasConnectionEventArgs)
        'Sub which is executed when connection watcher indicates that connection is disconnected by an interrupt.
        conup = False
        If (intDisconnected = False) Then 'Check whether connection is disconnected by the application or by external factors.
            Dispatcher.BeginInvoke(Sub() ResetUiElements())

            IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  Connection  interrupted and disconnected externally")
        End If
    End Sub

    Private Sub ResetUiElements()
        lb_con.Content = "Connect"
        lb_con.Margin = New Thickness(374, 192, 0, 0)
        lb1.Content = "Let's Connect"
        lb1.Margin = New Thickness(183, 68, 146, 0)
    End Sub
    Private Sub dialstatechanged(sender As System.Object, e As StateChangedEventArgs)
        'Sub which is executed on the dialer state change event.
        IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  " + e.State.ToString)

    End Sub

    Private Sub dialcomplete(sender As System.Object, e As DialCompletedEventArgs)
        'Sub which is executed on the dialer complete event.

        'If connection is succesffully established then execute if statement.
        If (e.Connected) Then

            conup = True
            lb1.Content = "Enjoy"
            lb1.Margin = New Thickness(330, 68, 180, 0)
            connecting.Visibility = Windows.Visibility.Hidden
            IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  Connection Established to a " + tempProtocolName + " Server: (" + tb_server.Text + ") with Username: (" + tb_username.Text + ") and Password: (" + tb_psdd.Text + ") and Pre-Shared Key: (" + tempPSKEY + ")")

            'Save the current details for reuse.
            My.Settings.serveradd = tb_server.Text
            My.Settings.serveruser = tb_username.Text
            My.Settings.serverpass = tb_psdd.Text
            My.Settings.serverpskey = tb_pskey.Text
            My.Settings.index = com_protocols.SelectedIndex
            My.Settings.Save()

            'If there is any type of connection error occurs while connection is being established.
        ElseIf (e.Error IsNot Nothing) Then
            MsgBox(e.Error.ToString(), MsgBoxStyle.Critical, "Connection Error")
            connecting.Visibility = Windows.Visibility.Hidden
            lb_con.Content = "Connect"
            lb_con.Margin = New Thickness(374, 192, 0, 0)
            IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  " + e.Error.ToString())
            'If connction timed out while connection is being established.
        ElseIf (e.TimedOut) Then
            MsgBox("Connection attempt timed out.", MsgBoxStyle.Critical, "Timed Out")
            connecting.Visibility = Windows.Visibility.Hidden
            lb_con.Content = "Connect"
            lb_con.Margin = New Thickness(374, 192, 0, 0)
            IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  Connection attempt timed out.")

        End If

    End Sub

    Private Sub rec2_MouseDown(sender As Object, e As MouseButtonEventArgs) Handles rec2.MouseDown
        If e.LeftButton = MouseButtonState.Pressed Then
            connection()
        End If
    End Sub

    Private Sub lb_con_MouseDown(sender As Object, e As MouseButtonEventArgs) Handles lb_con.MouseDown
        If e.LeftButton = MouseButtonState.Pressed Then
            connection()
        End If
    End Sub

    Private Sub closeapp_MouseDown(sender As Object, e As MouseButtonEventArgs) Handles closeapp.MouseDown

        'Before closing application, confirm user, if user allows then first check if a connection is alive, if it is then disconnect it first.


        Dim ans = MsgBox("Are sure as it will close any live connections?", MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo, "Exit Application")

        If (ans = vbYes) Then

            If (conup = True) Then

                If (rasdialer.IsBusy) Then
                    rasdialer.DialAsyncCancel()
                Else
                    Dim con As RasConnection = RasConnection.GetActiveConnectionByHandle(rashandler)

                    If (con IsNot Nothing) Then
                        con.HangUp()
                    End If

                End If
                IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  Successfully disconnected live connection")


            End If
            IO.File.AppendAllText(My.Application.Info.DirectoryPath + "\logs.txt", vbNewLine + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "  >>  SurfOpenly Application Closing")


            'Close the application.
            System.Windows.Application.Current.Shutdown()
        End If
    End Sub

    Private Sub minimizeapp_MouseDown(sender As Object, e As MouseButtonEventArgs) Handles minimizeapp.MouseDown
        Me.WindowState = WindowState.Minimized

    End Sub



    Private Sub infoapp_Click(sender As Object, e As RoutedEventArgs) Handles infoapp.Click
        MsgBox("Author Name: Zubair Khalid" + vbNewLine + vbNewLine + "Author Email: zubarkhald130@gmail.com" + vbNewLine + vbNewLine + "Facebook: www.facebook.com/m.zubair.30" + vbNewLine + vbNewLine + "Twitter: twitter.com/zubairkhalid130" + vbNewLine + vbNewLine + "YouTube: www.youtube.com/c/VBCoders", MsgBoxStyle.Information, "Author")

    End Sub

    Private Sub viewlogs_Click(sender As Object, e As RoutedEventArgs) Handles viewlogs.Click
        'View log file.

        If (IO.File.Exists(My.Application.Info.DirectoryPath + "\logs.txt")) Then
            Process.Start(My.Application.Info.DirectoryPath + "\logs.txt", IO.FileMode.Open)
        Else
            MsgBox("Log file is not found.", MsgBoxStyle.Critical, "No Logs")

        End If
    End Sub
End Class
